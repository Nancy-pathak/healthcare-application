from django.contrib import admin
from django.urls import path
from healthapp import views
from django.conf.urls.static import static
from healthcare import settings

urlpatterns = [
    
    path('home',views.home),
    path('medical_details',views.medical_details),
    path('footer',views.foter),
    path('about',views.about),
    path('contact',views.contact),
    path('appointment',views.appointment),
    path('logout',views.user_logout),
    path('medical',views.medical),
    # path('catfilter/<cv>',views.catfilter),#cv will be anything we write cv here becz in function views.py we pass cv
    # path('sort/<sv>',views.sort),# for sorted value
    # path('range',views.range),
    path('addtocart/<pid>',views.addtocart),
    path('viewcart',views.viewcart),
    path('remove/<cid>',views.remove),
    path('pdetails/<pid>',views.pdetails), 
    path('updateqty/<qv>/<cid>',views.updateqty),
    path('placeorder',views.placeorder),
    path('makepayment',views.makepayment)
                
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)